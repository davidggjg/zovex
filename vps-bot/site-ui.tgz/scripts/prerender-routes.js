// scripts/prerender-routes.js
// אחרי ה-build, יוצר תיקייה אמיתית לכל route (סרט/סדרה) עם עותק מותאם-אישית
// של index.html: כותרת, תיאור, ותמונת פוסטר (og:image) ספציפיים לאותו סרט/
// סדרה, ועוד תגית JSON-LD (schema.org). זה מה שמאפשר לגוגל בפועל "לראות"
// עמוד נפרד לכל תוכן - עם התמונה והשם הנכונים - במקום שכל דף באתר יראה
// לגוגל בדיוק אותו כותרת/תיאור גנרי בלי תמונה, שזו הסיבה שהפוסטרים לא
// הופיעו בגוגל תמונות.

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
// DIST_DIR נשלט מהסביבה. בלעדיו הסקריפט יודע לעבוד רק על dist/ שליד
// הקוד, ולכן תיקון של דפי ה-SEO חייב בנייה מלאה מחדש. הדפים האלה תלויים
// רק ב-index.html ובקטלוג, ולכן אפשר לייצר אותם מחדש במקום — על תיקיית
// האתר החיה — וזה מה שהופך תיקון כזה מ"בנייה ופריסה" לפקודה אחת.
const DIST_DIR = process.env.DIST_DIR || path.join(ROOT, "dist");
const MOVIES_PATH = path.join(ROOT, "public", "movies.json");
const INDEX_HTML = path.join(DIST_DIR, "index.html");
// build:vps כבר מייצא SITE_URL, אבל איש לא קרא אותו — הערך היה
// מקודד קשיח, והדפים שנוצרו הצביעו על אתר ה-GitHub Pages שנסגר.
const SITE_URL = process.env.SITE_URL || "https://zovex.duckdns.org";
const CATALOG_URL = process.env.CATALOG_URL || "https://zovex.duckdns.org/content/lite";

// כותר שנכנס לכתובת כשאין שם אנגלי. סימנים כמו ‎:‎ הופכים ל-‎%3A‎
// ומכערים כתובת שממילא מקודדת — נמדד: 66 כותרים בקטלוג מכילים
// נקודתיים (‎אקס-מן: אפוקליפסה‎). הם יורדים, ורווחים הופכים למקף
// יחיד. זו רק רשת ביטחון: היעד הוא slug אנגלי אמיתי מ-seo_fix.py.
function cleanForUrl(name) {
  return String(name || "")
    .replace(/[:\u2013\u2014"'`?#\[\]@!$&()*+,;=.]/g, " ")
    .trim()
    .replace(/\s+/g, "-");
}

function slugifyMovie(movie) {
  if (movie.custom_slug) return movie.custom_slug;
  const base = encodeURIComponent(cleanForUrl(movie.title));
  return `${base}-${(movie.id || "").slice(0, 6)}`;
}

function slugifySeries(seriesName, customSlug) {
  if (customSlug) return customSlug;
  return encodeURIComponent(cleanForUrl(seriesName));
}

// אוסף route -> מטא-דאטה (כותרת/תיאור/פוסטר/סוג) לכל סרט וסדרה
function collectRoutes(movies) {
  const routes = new Map();
  const seriesSeen = new Map(); // series_name -> נציג ראשון (לפוסטר/תיאור)
  // כתובת ישנה → הכתובת החדשה שלה. ‎old_slugs‎ נכתב ב-seo_fix.py בכל
  // פעם שהוא מחליף slug, בדיוק כדי שהקישור הישן ישרוד.
  const aliases = new Map();

  const noteAliases = (m, current) => {
    for (const old of m.old_slugs || []) {
      const o = String(old || "").trim();
      if (o && o !== current && !aliases.has(o)) aliases.set(o, current);
    }
    // גם הצורה שהכתובת הייתה לפני cleanForUrl. היא אולי כבר מאונדקסת
    // (‎…%3A…‎), ובלי זה ניקוי הנקודתיים היה מוחק אותה בשקט — בדיוק
    // התקלה שבגללה נבנה מנגנון ה-canonical מלכתחילה.
    if (!m.custom_slug) {
      const name = m.series_name || m.title || "";
      const legacy = m.series_name
        ? encodeURIComponent(name.replace(/ /g, "-"))
        : `${encodeURIComponent(name.replace(/ /g, "-"))}-${(m.id || "").slice(0, 6)}`;
      if (legacy && legacy !== current && !aliases.has(legacy)) {
        aliases.set(legacy, current);
      }
    }
  };

  for (const m of movies) {
    if (m.series_name) {
      if (!seriesSeen.has(m.series_name)) seriesSeen.set(m.series_name, m);
    } else {
      noteAliases(m, slugifyMovie(m));
      routes.set(slugifyMovie(m), {
        title: m.title,
        description: m.description,
        thumbnail_url: m.thumbnail_url,
        year: m.year,
        type: "movie",
      });
    }
  }

  for (const [name, rep] of seriesSeen.entries()) {
    const slug = slugifySeries(name, rep.custom_slug);
    noteAliases(rep, slug);
    routes.set(slug, {
      title: name,
      description: rep.description,
      thumbnail_url: rep.thumbnail_url,
      year: rep.year,
      type: "series",
    });
  }

  // כתובת ישנה מקבלת דף משלה, שה-canonical שלו מצביע על החדשה. אלא
  // אם היא במקרה גם כתובת חיה — אז לא נוגעים בה.
  for (const [old, current] of aliases.entries()) {
    if (routes.has(old) || !routes.has(current)) continue;
    routes.set(old, { ...routes.get(current), canonicalTo: current });
  }

  return routes;
}

// ‎decodeURIComponent‎ על קלט מהקטלוג הוא פענוח של מחרוזת שלא אנחנו
// כתבנו, והיא הופכת לשם קובץ. ‎%2F‎ היה הופך לקו נטוי ויוצר תיקייה
// מקוננת, ו-‎%2E%2E%2F‎ היה יוצא מתיקיית האתר. שם שאינו רכיב נתיב אחד
// ונקי — נדחה, ומדווח בסוף ההרצה.
function safeDirName(route) {
  let name;
  try {
    name = decodeURIComponent(route);
  } catch {
    return null; // קידוד פגום — %ZZ
  }
  if (!name || name === "." || name === "..") return null;
  if (name.includes("/") || name.includes("\\") || name.includes("\0")) return null;
  if (name.startsWith(".")) return null;
  return name;
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapeJson(str) {
  return JSON.stringify(String(str || ""));
}

function buildPageHtml(baseHtml, route, meta) {
  const title = `${meta.title} - צפייה ישירה | ZOVEX`;
  const rawDesc = (meta.description || `צפייה ישירה ב${meta.title} - בחינם, באתר ZOVEX.`).trim();
  const description = rawDesc.length > 200 ? rawDesc.slice(0, 197) + "..." : rawDesc;
  // עם לוכסן בסוף - זו הכתובת שבאמת מחזירה 200 ישירות (GitHub Pages מפנה
  // 301 מהגרסה בלי הלוכסן, כי route כאן הוא תיקייה עם index.html בפנים)
  // כתובת ישנה שה-slug שלה הוחלף מצביעה על החדשה. בלי זה היא הייתה
  // נעלמת מהבנייה, וכל מה שגוגל כבר אינדקס עליה היה הופך ל-404 —
  // כלומר שינוי ה-slug היה מוחק דירוג במקום להעביר אותו.
  const url = meta.canonicalTo
    ? `${SITE_URL}/${meta.canonicalTo}/`
    : `${SITE_URL}/${route}/`;
  const image = meta.thumbnail_url || "";
  const ogType = meta.type === "series" ? "video.tv_show" : "video.movie";
  const schemaType = meta.type === "series" ? "TVSeries" : "Movie";

  let html = baseHtml;
  html = html.replace(/<title>.*?<\/title>/s, `<title>${escapeHtml(title)}</title>`);
  html = html.replace(/<meta name="description" content=".*?" \/>/s, `<meta name="description" content="${escapeHtml(description)}" />`);
  html = html.replace(/<meta property="og:title" content=".*?" \/>/s, `<meta property="og:title" content="${escapeHtml(title)}" />`);
  html = html.replace(/<meta property="og:description" content=".*?" \/>/s, `<meta property="og:description" content="${escapeHtml(description)}" />`);
  html = html.replace(/<meta property="og:type" content=".*?" \/>/s, `<meta property="og:type" content="${ogType}" />`);

  // כל התגיות שהקובץ הזה מספק בעצמו לכל דף — מסלקים קודם את הגרסה
  // הגלובלית שיושבת ב-index.html, אחרת נוצרות כפילויות. סורק שרואה שתי
  // תגיות og:image לוקח את הראשונה, וזו הגלובלית — כלומר כל דף סרט היה
  // מציג את כרטיס המותג הגנרי במקום את הפוסטר, בדיוק מה שהקובץ הזה נכתב
  // כדי למנוע. גם og:image:width/height/type חייבים ללכת: הם תיארו את
  // התמונה הגלובלית (1200x630 png) ולא את הפוסטר שמגיע במידות אחרות.
  html = html.replace(
    /[ \t]*<meta\s+(?:property|name)="(?:og:image(?::[a-z_]+)?|og:url|twitter:card|twitter:title|twitter:description|twitter:image(?::[a-z]+)?)"[^>]*\/?>[ \t]*\r?\n?/gi,
    ""
  );

  const extraTags = [
    `<meta property="og:url" content="${escapeHtml(url)}" />`,
    image ? `<meta property="og:image" content="${escapeHtml(image)}" />` : "",
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${escapeHtml(title)}" />`,
    `<meta name="twitter:description" content="${escapeHtml(description)}" />`,
    image ? `<meta name="twitter:image" content="${escapeHtml(image)}" />` : "",
    `<link rel="canonical" href="${escapeHtml(url)}" />`,
    // גוגל מתאחד לפי canonical, אבל מבקר אנושי שמגיע מקישור ישן צריך
    // להגיע לדף עצמו — ה-SPA לא ימצא את הפריט לפי ה-slug שכבר הוחלף.
    meta.canonicalTo
      ? `<script>location.replace(${JSON.stringify("/" + meta.canonicalTo + "/")} + location.search + location.hash);</script>`
      : "",
    `<script type="application/ld+json">${JSON.stringify({
      "@context": "https://schema.org",
      "@type": schemaType,
      name: meta.title,
      description: description,
      image: image || undefined,
      dateCreated: meta.year ? String(meta.year) : undefined,
      url,
    })}</script>`,
  ].filter(Boolean).join("\n    ");

  html = html.replace("</head>", `    ${extraTags}\n  </head>`);

  // תוכן סטטי אמיתי בתוך #root — כדי שגם מי שלא מריץ JS (בוטים, תצוגות-
  // תצוגה-מקדימה ברשתות חברתיות) יראה טקסט/תמונה אמיתיים בתגובה הראשונה,
  // לא רק תגיות <head>. React (createRoot().render) מחליף את זה לגמרי
  // ברגע שהוא עולה - אין כאן hydrate, אז אין סיכון לשגיאת mismatch.
  const staticBody = `
      <h1>${escapeHtml(meta.title)}</h1>
      ${image ? `<img src="${escapeHtml(image)}" alt="${escapeHtml(meta.title)}" style="max-width:280px;border-radius:8px" />` : ""}
      <p>${escapeHtml(description)}</p>
      <p><a href="${escapeHtml(SITE_URL)}/">צפייה ישירה בחינם - ZOVEX</a></p>
    `;
  html = html.replace(
    '<div id="root"></div>',
    `<div id="root" style="background:#0a0a0a;color:#fff;font-family:Arial,sans-serif;padding:20px;direction:rtl">${staticBody}</div>`
  );
  return html;
}

// טעינת הקטלוג. עד עכשיו, קובץ חסר גרם ל"skipping" שקט — והבנייה הצליחה
// והפיקה dist בלי אף דף ייעודי. מכיוון שהפריסה מוחקת את כל תיקיית האתר
// לפני שהיא פורסת, בנייה כזאת מוחקת בשקט אלפי דפי נחיתה מגוגל. לכן אם
// הקובץ המקומי חסר, מושכים את הקטלוג מהאתר החי במקום לוותר.
async function loadCatalog(tag) {
  if (fs.existsSync(MOVIES_PATH)) {
    try {
      const arr = JSON.parse(fs.readFileSync(MOVIES_PATH, "utf-8"));
      if (Array.isArray(arr)) return arr;
      console.warn(`[${tag}] movies.json אינו מערך — מנסה למשוך מהאתר`);
    } catch (e) {
      console.warn(`[${tag}] movies.json פגום (${e.message}) — מנסה למשוך מהאתר`);
    }
  }
  try {
    console.log(`[${tag}] מושך קטלוג מ-${CATALOG_URL}`);
    const res = await fetch(CATALOG_URL);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const arr = await res.json();
    if (!Array.isArray(arr)) throw new Error("התשובה אינה מערך");
    console.log(`[${tag}] התקבלו ${arr.length} פריטים`);
    return arr;
  } catch (e) {
    console.error(`[${tag}] לא ניתן לטעון קטלוג: ${e.message}`);
    return null;
  }
}

async function prerender() {
  if (!fs.existsSync(DIST_DIR) || !fs.existsSync(INDEX_HTML)) {
    console.warn("[prerender] dist/index.html not found — run this after `vite build`.");
    return;
  }
  const indexHtml = fs.readFileSync(INDEX_HTML, "utf-8");
  const movies = await loadCatalog("prerender");
  if (!movies) return;

  const routes = collectRoutes(movies);
  let created = 0;

  let skippedUnsafe = 0;
  for (const [route, meta] of routes.entries()) {
    if (!route) continue;
    // [fix_encoded_dirs] שם התיקייה מפוענח, הכתובת נשארת מקודדת.
    //
    // ‎slugifyMovie‎ מחזיר ‎encodeURIComponent(...)‎, ועד כאן נוצרה תיקייה
    // ששמה בפועל ‎%D7%90%D7%95%D7%99%D7%91-aa551c‎. אבל כל שרת מפענח את
    // הכתובת לפני שהוא פונה לדיסק, ולכן בקשה ל-‎/%D7%90…/‎ חיפשה
    // ‎אויב-המדינה-aa551c‎ — תיקייה שלא נוצרה מעולם. ‎try_files‎ נפל חזרה
    // ל-‎/index.html‎ והגיש את דף הבית בקוד 200.
    //
    // נמדד על השרת החי: 393 תיקיות בשם מקודד, 0 בעברית. כלומר כל סרט
    // וסדרה עם כותר עברי הוגשו לגוגל כשיבוט של דף הבית — לא דפים חסרים
    // אלא מאות כפילויות, שהן סיגנל איכות שלילי לכל הדומיין.
    //
    // ‎route‎ ממשיך לשמש ל-‎canonical‎ ולסייטמאפ: שם הצורה המקודדת היא
    // הנכונה, והיא גם מה שהסורק מבקש בפועל.
    const diskName = safeDirName(route);
    if (!diskName) {
      skippedUnsafe++;
      continue;
    }
    const routeDir = path.join(DIST_DIR, diskName);
    try {
      fs.mkdirSync(routeDir, { recursive: true });
      const pageHtml = buildPageHtml(indexHtml, route, meta);
      fs.writeFileSync(path.join(routeDir, "index.html"), pageHtml, "utf-8");
      created++;
    } catch (e) {
      console.warn(`[prerender] Failed to create route "${route}":`, e.message);
    }
  }

  console.log(`[prerender] Created ${created} static route folders in ` +
              `${DIST_DIR} with per-page SEO tags.`);
  if (skippedUnsafe) {
    console.warn(`[prerender] ${skippedUnsafe} routes skipped: ` +
                 `slug decodes to an unsafe directory name.`);
  }
}

await prerender();
